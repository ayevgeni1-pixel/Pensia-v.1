
import 'package:flutter/material.dart';

void main() {
  runApp(const InvestMateApp());
}

class InvestMateApp extends StatelessWidget {
  const InvestMateApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'InvestMate AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF050914),
        cardColor: const Color(0xFF10192B),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF18D4FF),
          secondary: Color(0xFF00DF88),
          surface: Color(0xFF10192B),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

class Holding {
  final String symbol;
  final String name;
  final double quantity;
  final double averagePrice;
  final double currentPrice;
  final double dayPnl;
  final String currency;
  final String type;
  final String risk;

  const Holding({
    required this.symbol,
    required this.name,
    required this.quantity,
    required this.averagePrice,
    required this.currentPrice,
    required this.dayPnl,
    required this.currency,
    required this.type,
    required this.risk,
  });

  double get value => quantity * currentPrice;
  double get cost => quantity * averagePrice;
  double get pnl => value - cost;
}

class IlsAsset {
  final String symbol;
  final String name;
  final double? quantity;
  final double? averageAgorot;
  final double? currentAgorot;
  final double? valueIls;
  final String type;
  final String risk;

  const IlsAsset({
    required this.symbol,
    required this.name,
    this.quantity,
    this.averageAgorot,
    this.currentAgorot,
    this.valueIls,
    required this.type,
    required this.risk,
  });

  double get value {
    if (valueIls != null) return valueIls!;
    return (quantity ?? 0) * (currentAgorot ?? 0) / 100.0;
  }

  double get cost {
    if (valueIls != null) return valueIls!;
    return (quantity ?? 0) * (averageAgorot ?? 0) / 100.0;
  }

  double get pnl => value - cost;
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

enum AppTab { today, portfolio, pension, sandbox, ai, journal }

class _HomeScreenState extends State<HomeScreen> {
  AppTab tab = AppTab.today;
  double fx = 2.99;
  double annualYield = 4.0;

  final List<Holding> us = const [
    Holding(symbol: 'DRAM', name: 'Roundhill Memory ETF', quantity: 100, averagePrice: 70.5479, currentPrice: 64.78, dayPnl: -108, currency: 'USD', type: 'Memory ETF', risk: 'High'),
    Holding(symbol: 'NVDA', name: 'Nvidia Corp', quantity: 500, averagePrice: 57.0929, currentPrice: 197.63, dayPnl: 25, currency: 'USD', type: 'AI / Stock', risk: 'High'),
    Holding(symbol: 'SOXL', name: 'Direxion Semiconductor Bull 3x', quantity: 100, averagePrice: 60.7484, currentPrice: 224.52, dayPnl: 697, currency: 'USD', type: '3x Leveraged ETF', risk: 'Extreme'),
    Holding(symbol: 'SOXQ', name: 'Invesco Semiconductor ETF', quantity: 40, averagePrice: 111, currentPrice: 106.85, dayPnl: 69.6, currency: 'USD', type: 'Semiconductor ETF', risk: 'High'),
    Holding(symbol: 'SPYM', name: 'S&P 500 Momentum', quantity: 100, averagePrice: 88.64, currentPrice: 88.05, dayPnl: 28, currency: 'USD', type: 'Momentum ETF', risk: 'Medium'),
  ];

  final List<IlsAsset> ils = const [
    IlsAsset(symbol: '5112628', name: '125 TA A4', quantity: 80, averageAgorot: 459.34, currentAgorot: 430.87, type: 'TASE Fund', risk: 'Medium'),
    IlsAsset(symbol: '5122965', name: 'Nasdaq 100 monthly hedged', quantity: 200, averageAgorot: 378.07, currentAgorot: 381.38, type: 'TASE Nasdaq', risk: 'High'),
    IlsAsset(symbol: '1161827', name: 'Harel Technology', quantity: 160, averageAgorot: 292.11, currentAgorot: 281.10, type: 'TASE Tech', risk: 'High'),
    IlsAsset(symbol: '1194141', name: 'Keren Gidur Strategy-Multi', valueIls: 10000, type: 'Hedge Fund', risk: 'Medium'),
    IlsAsset(symbol: '1194232', name: 'Long-short fund', valueIls: 3000, type: 'Hedge Fund', risk: 'Medium'),
    IlsAsset(symbol: '5136866', name: 'Keren Kaspit', valueIls: 36000, type: 'Cash Fund', risk: 'Low'),
    IlsAsset(symbol: 'HISHTALMUT', name: 'Keren Hishtalmut', valueIls: 185000, type: 'Long-term / Pension asset', risk: 'Medium'),
  ];

  final List<String> journal = [
    '2026-07-02 · Pension · Added guaranteed income ₪6,500/month',
    '2026-07-02 · Risk · SOXL marked as 3x leveraged ETF',
    '2026-07-02 · Data · Portfolio imported from screenshots',
  ];

  double get usTotal => us.fold(0, (sum, h) => sum + h.value);
  double get usDay => us.fold(0, (sum, h) => sum + h.dayPnl);
  double get ilsTotal => ils.fold(0, (sum, h) => sum + h.value);
  double get totalUsd => usTotal + ilsTotal / fx;
  double get totalIls => usTotal * fx + ilsTotal;
  double get nvdaWeight => us.firstWhere((h) => h.symbol == 'NVDA').value / totalUsd * 100;
  double get soxlWeight => us.firstWhere((h) => h.symbol == 'SOXL').value / totalUsd * 100;
  int get investmentIq {
    final raw = 88 - (nvdaWeight > 35 ? (nvdaWeight - 35) * 0.3 : 0) - soxlWeight * 0.25;
    return raw.clamp(60, 95).round();
  }

  String usd(double value) => '\$${value.round().toString().replaceAllMapped(RegExp(r'(\d)(?=(\d{3})+(?!\d))'), (m) => '${m[1]},')}';
  String nis(double value) => '₪${value.round().toString().replaceAllMapped(RegExp(r'(\d)(?=(\d{3})+(?!\d))'), (m) => '${m[1]},')}';

  @override
  Widget build(BuildContext context) {
    final monthlyInvestmentIncome = totalIls * (annualYield / 100) / 12;

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 90),
                children: [
                  _header(),
                  _hero(monthlyInvestmentIncome),
                  const SizedBox(height: 12),
                  _tabs(),
                  const SizedBox(height: 8),
                  _content(monthlyInvestmentIncome),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _header() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('INVESTMATE AI', style: TextStyle(fontSize: 12, letterSpacing: 3, color: Color(0xFF91A0B8), fontWeight: FontWeight.w900)),
              SizedBox(height: 8),
              Text('Android Preview', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
              SizedBox(height: 4),
              Text('Flutter APK project · portfolio, pension, AI, sandbox', style: TextStyle(color: Color(0xFF91A0B8), fontSize: 13)),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          decoration: BoxDecoration(
            color: const Color(0x2200DF88),
            border: Border.all(color: const Color(0x6600DF88)),
            borderRadius: BorderRadius.circular(999),
          ),
          child: const Text('🟢 Local', style: TextStyle(color: Color(0xFF00DF88), fontWeight: FontWeight.w800, fontSize: 12)),
        ),
      ],
    );
  }

  Widget _hero(double monthlyInvestmentIncome) {
    return _card(
      borderColor: const Color(0x5518D4FF),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Known capital', style: TextStyle(color: Color(0xFF91A0B8), fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          Text(usd(totalUsd), style: const TextStyle(color: Color(0xFF18D4FF), fontSize: 38, fontWeight: FontWeight.w900)),
          Text('≈ ${nis(totalIls)} · US ${usd(usTotal)} · Israel ${nis(ilsTotal)} · USD/ILS ${fx.toStringAsFixed(2)}', style: const TextStyle(color: Color(0xFF91A0B8), fontSize: 13)),
          const SizedBox(height: 14),
          GridView.count(
            crossAxisCount: 2,
            childAspectRatio: 2.45,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            children: [
              _mini('Investment IQ', '$investmentIq/100'),
              _mini('Guaranteed', '₪6,500/mo'),
              _mini('Investment income', '${nis(monthlyInvestmentIncome)}/mo'),
              _mini('Today', usd(usDay)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _mini(String label, String value) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: const Color(0x77050914), borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0x22FFFFFF))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
        Text(label, style: const TextStyle(color: Color(0xFF91A0B8), fontSize: 12)),
        const SizedBox(height: 5),
        Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
      ]),
    );
  }

  Widget _tabs() {
    final items = [
      (AppTab.today, 'Сегодня'),
      (AppTab.portfolio, 'Портфель'),
      (AppTab.pension, 'Пенсия'),
      (AppTab.sandbox, 'Песочница'),
      (AppTab.ai, 'AI'),
      (AppTab.journal, 'Журнал'),
    ];
    return Wrap(
      spacing: 7,
      runSpacing: 7,
      children: items.map((x) {
        final selected = tab == x.$1;
        return GestureDetector(
          onTap: () => setState(() => tab = x.$1),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(color: selected ? const Color(0xFF18D4FF) : const Color(0xFF17233A), borderRadius: BorderRadius.circular(14)),
            child: Text(x.$2, style: TextStyle(color: selected ? const Color(0xFF03111B) : const Color(0xFF91A0B8), fontWeight: FontWeight.w900, fontSize: 12)),
          ),
        );
      }).toList(),
    );
  }

  Widget _content(double monthlyInvestmentIncome) {
    switch (tab) {
      case AppTab.today:
        return _today();
      case AppTab.portfolio:
        return _portfolio();
      case AppTab.pension:
        return _pension(monthlyInvestmentIncome);
      case AppTab.sandbox:
        return _sandbox();
      case AppTab.ai:
        return _ai(monthlyInvestmentIncome);
      case AppTab.journal:
        return _journal();
    }
  }

  Widget _today() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      _section('Утренний брифинг'),
      _card(child: _textBlock([
        ('Что произошло', 'Портфель США: ${usd(usTotal)}. Сегодня: ${usd(usDay)}.'),
        ('Что важно', 'NVDA около ${nvdaWeight.toStringAsFixed(1)}%, SOXL около ${soxlWeight.toStringAsFixed(1)}% общего капитала.'),
        ('Что делать сегодня', 'Не увеличивать SOXL. Контролировать риск, а не дневную доходность.'),
      ])),
      _section('Здоровье портфеля'),
      _card(child: Row(children: [
        _iqCircle(),
        const SizedBox(width: 16),
        Expanded(child: Text('Investment IQ: $investmentIq/100\n+ капитал существенный\n+ гарантированный доход ₪6,500/мес\n− NVDA concentration\n− SOXL 3x risk', style: const TextStyle(color: Color(0xFFC6D0E4), height: 1.55))),
      ])),
    ]);
  }

  Widget _portfolio() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      _section('США · Meitav'),
      _card(child: Column(children: us.map(_holdingTile).toList())),
      _section('Израиль · ILS'),
      _card(child: Column(children: ils.map(_ilsTile).toList())),
    ]);
  }

  Widget _pension(double monthlyInvestmentIncome) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      _section('Пенсионный центр'),
      _card(borderColor: const Color(0x5518D4FF), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Гарантированный доход', style: TextStyle(color: Color(0xFF91A0B8))),
        const SizedBox(height: 6),
        const Text('₪6,500/мес', style: TextStyle(color: Color(0xFF18D4FF), fontSize: 36, fontWeight: FontWeight.w900)),
        const Text('Пенсия ₪4,000 + Битуах Леуми ₪2,500', style: TextStyle(color: Color(0xFF91A0B8))),
      ])),
      _card(child: Column(children: [
        _row('Пенсия', '₪4,000'),
        _row('Битуах Леуми', '₪2,500'),
        _row('Инвест. доход при ${annualYield.toStringAsFixed(1)}%', '${nis(monthlyInvestmentIncome)}/мес'),
        _row('Итого потенциально', '${nis(6500 + monthlyInvestmentIncome)}/мес'),
      ])),
      _card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Annual yield scenario', style: TextStyle(color: Color(0xFF91A0B8))),
        Slider(value: annualYield, min: 2, max: 8, divisions: 12, label: annualYield.toStringAsFixed(1), onChanged: (v) => setState(() => annualYield = v)),
      ])),
    ]);
  }

  Widget _sandbox() {
    final sellSoxl50 = us.firstWhere((h) => h.symbol == 'SOXL').currentPrice * 50;
    final newSoxlWeight = (us.firstWhere((h) => h.symbol == 'SOXL').value - sellSoxl50) / totalUsd * 100;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      _section('Песочница решений'),
      _card(child: _textBlock([
        ('Сценарий', 'Продать 50 SOXL.'),
        ('Эффект', 'SOXL снизится примерно с ${soxlWeight.toStringAsFixed(1)}% до ${newSoxlWeight.toStringAsFixed(1)}%.'),
        ('AI вывод', 'Сценарий улучшает риск-профиль, но уменьшает агрессивный semiconductor upside.'),
      ])),
      _card(child: _textBlock([
        ('Следующий сценарий', 'Продать 100 NVDA или добавить ₪50,000 в Керен Каспит.'),
        ('Зачем', 'Сравнить влияние на риск, Investment IQ и пенсионный доход.'),
      ])),
    ]);
  }

  Widget _ai(double monthlyInvestmentIncome) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      _section('AI-директор'),
      _card(child: _textBlock([
        ('Решение дня', 'Держать структуру без изменений. Не увеличивать SOXL.'),
        ('Почему', 'Портфель уже сильно зависит от AI/semiconductors, а до пенсии меньше трех лет.'),
        ('Пенсионный контекст', 'При ${annualYield.toStringAsFixed(1)}% годовых инвестиционный капитал дает около ${nis(monthlyInvestmentIncome)}/мес.'),
      ])),
      _card(borderColor: const Color(0x55FF5364), child: const Text('Жестко: SOXL нельзя считать пенсионным активом. Это ускоритель риска.', style: TextStyle(color: Color(0xFFFFB4BE), height: 1.55))),
    ]);
  }

  Widget _journal() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      _section('Журнал решений'),
      _card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: journal.map((x) => Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(x, style: const TextStyle(height: 1.4)))).toList())),
      _card(child: const Text('Цель журнала — анализировать качество решений, а не только доходность. После 20–30 записей станет видно, какие действия были дисциплинированными, а какие эмоциональными.', style: TextStyle(color: Color(0xFFC6D0E4), height: 1.55))),
    ]);
  }

  Widget _section(String title) => Padding(
    padding: const EdgeInsets.only(top: 10, bottom: 8),
    child: Text(title.toUpperCase(), style: const TextStyle(color: Color(0xFF91A0B8), fontSize: 12, letterSpacing: 2.2, fontWeight: FontWeight.w900)),
  );

  Widget _card({required Widget child, Color borderColor = const Color(0xFF263854)}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 13),
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF17233A), Color(0xFF10192B)], begin: Alignment.topCenter, end: Alignment.bottomCenter),
        border: Border.all(color: borderColor),
        borderRadius: BorderRadius.circular(24),
      ),
      child: child,
    );
  }

  Widget _textBlock(List<(String, String)> items) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: items.map((x) => Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: RichText(text: TextSpan(style: const TextStyle(color: Color(0xFFC6D0E4), height: 1.55, fontSize: 15), children: [
        TextSpan(text: '${x.$1}:\n', style: const TextStyle(color: Color(0xFF18D4FF), fontWeight: FontWeight.w900)),
        TextSpan(text: x.$2),
      ])),
    )).toList()),
    );
  }

  Widget _holdingTile(Holding h) {
    final weight = h.value / totalUsd * 100;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 9),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(h.symbol, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            Text('${h.name} · ${h.type}', style: const TextStyle(color: Color(0xFF91A0B8), fontSize: 12)),
          ])),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(usd(h.value), style: const TextStyle(fontWeight: FontWeight.w900)),
            Text('${weight.toStringAsFixed(1)}% всего', style: const TextStyle(color: Color(0xFF91A0B8), fontSize: 12)),
          ]),
        ]),
        const SizedBox(height: 8),
        LinearProgressIndicator(value: (weight / 100).clamp(0, 1), backgroundColor: const Color(0xFF263854), color: const Color(0xFF18D4FF)),
      ]),
    );
  }

  Widget _ilsTile(IlsAsset h) {
    final weight = (h.value / fx) / totalUsd * 100;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 9),
      child: Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(h.symbol, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
          Text('${h.name} · ${h.type}', style: const TextStyle(color: Color(0xFF91A0B8), fontSize: 12)),
        ])),
        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text(nis(h.value), style: const TextStyle(fontWeight: FontWeight.w900)),
          Text('${weight.toStringAsFixed(1)}% всего', style: const TextStyle(color: Color(0xFF91A0B8), fontSize: 12)),
        ]),
      ]),
    );
  }

  Widget _row(String a, String b) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 9),
    child: Row(children: [Expanded(child: Text(a, style: const TextStyle(color: Color(0xFF91A0B8)))), Text(b, style: const TextStyle(fontWeight: FontWeight.w900))]),
  );

  Widget _iqCircle() {
    return Container(
      width: 96,
      height: 96,
      decoration: const BoxDecoration(shape: BoxShape.circle, gradient: SweepGradient(colors: [Color(0xFF00DF88), Color(0xFF263854)])),
      child: Center(
        child: Container(
          width: 70,
          height: 70,
          decoration: const BoxDecoration(color: Color(0xFF10192B), shape: BoxShape.circle),
          child: Center(child: Text('$investmentIq', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900))),
        ),
      ),
    );
  }
}
