# InvestMate AI — Flutter APK Project v2

## Как собрать APK

1. Загрузите весь проект в GitHub.
2. Откройте вкладку **Actions**.
3. Если GitHub показывает просто **workflow** — это нормально.
4. Откройте этот workflow.
5. Нажмите **Run workflow**.
6. Дождитесь завершения.
7. Откройте завершенный запуск.
8. Внизу в разделе **Artifacts** скачайте **InvestMateAI-debug-apk**.
9. Внутри будет `app-debug.apk`.

## Важно

Этот workflow сам создает Android-файлы командой:

```bash
flutter create --platforms=android .
```

Поэтому Android Studio не нужна.
